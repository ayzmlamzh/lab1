#include <stdio.h>
int main(void){
int age;
printf("Hi how old are you ? \n");
scanf("%d" , &age);
printf("You are %d years old \n", age);
return (0);
}
