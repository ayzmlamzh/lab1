#include <stdio.h>
int main(void){
/* this is my first programming */
printf("Hello World! \n");
printf("I Love C \n");
return(0);
}
